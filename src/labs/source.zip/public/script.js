/* eslint-env browser */

window.onload = () => {
  document.getElementById('form').onsubmit = (e) => {
    e.preventDefault()

    document.getElementById('submit').disabled = true
    document.getElementById('message').style.display = 'block'
    document.getElementById('error').style.display = 'none'
    document.getElementById('results').style.display = 'none'

    Array.prototype.forEach.call(document.getElementsByClassName('result'), x => {
      x.innerHTML = ''
    })

    fetch('/api?' + new URLSearchParams(new FormData(document.getElementById('form'))).toString())
      .then(response => response.json())
      .then(data => {
        if (data.error) {
          document.getElementById('submit').disabled = false
          document.getElementById('message').style.display = 'none'
          document.getElementById('error').innerHTML = 'Error: ' + data.error + '.'
          document.getElementById('error').style.display = 'block'
          return
        }

        data = data.sort((x, y) => x[1] - y[1]).reverse()
        data = data.map(x => [x[0], x[1] - Math.min(...data.map(x => x[1])), x[2]])
        data = data.map(x => [x[0], x[1] / Math.max(...data.map(x => x[1])), x[2]])
        data = data.map(x => [x[0], 8 - x[1] * 8, x[2]])
        data = data.map((x, i) => [x[0], Math.round((x[1] + i / data.length * 24) / 4), x[2]])

        data.forEach(element => {
          if (isNaN(element[1])) return

          const result = document.getElementsByClassName('result')[element[1]]
          const text = document.createElement('a')
          text.appendChild(document.createTextNode(element[0]))
          text.setAttribute('href', element[2])
          result.appendChild(text)
          result.innerHTML += '     '
        })

        Array.prototype.forEach.call(document.getElementsByClassName('result'), x => {
          x.innerHTML = x.innerHTML.trim()
        })

        document.getElementById('submit').disabled = false
        document.getElementById('message').style.display = 'none'
        document.getElementById('results').style.display = 'block'
      })
      .catch(error => {
        document.getElementById('submit').disabled = false
        document.getElementById('message').style.display = 'none'
        document.getElementById('error').innerHTML = 'Error: ' + error.message
        document.getElementById('error').style.display = 'block'
      })
  }
}
