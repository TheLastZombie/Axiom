const express = require('express')
const util = require('util')
const axios = require('axios')

const app = express()

app.get('/api', (req, res) => {
  console.log(util.inspect(req.query, {
    colors: true,
    breakLength: Infinity
  }))

  if (!req.query.user || !['artists', 'albums', 'tracks'].includes(req.query.mode) || !['7day', '1month', '3month', '6month', '12month', 'overall'].includes(req.query.period) || req.query.amount < 5 || req.query.amount > 100) {
    return res.send({
      error: 'Invalid arguments supplied'
    })
  }

  axios('https://ws.audioscrobbler.com/2.0/?method=user.gettop' + req.query.mode + '&user=' + encodeURIComponent(req.query.user) + '&period=' + req.query.period + '&limit=' + req.query.amount + '&api_key=52e8e86c171ed9affffa34580666927a&format=json').then(response => {
    switch (req.query.mode) {
      case 'artists':
        Promise.all(response.data.topartists.artist.map(async x => {
          const y = await axios('https://ws.audioscrobbler.com/2.0/?method=artist.getinfo&artist=' + encodeURIComponent(x.name) + '&api_key=52e8e86c171ed9affffa34580666927a&format=json')
          return Promise.resolve([x.name, y.data.artist ? Number(y.data.artist.stats.listeners) : 0, x.url])
        })).then(response => res.send(response))
        break

      case 'albums':
        Promise.all(response.data.topalbums.album.map(async x => {
          const y = await axios('https://ws.audioscrobbler.com/2.0/?method=album.getinfo&artist=' + encodeURIComponent(x.artist.name) + '&album=' + encodeURIComponent(x.name) + '&api_key=52e8e86c171ed9affffa34580666927a&format=json')
          return Promise.resolve([x.artist.name + ' – ' + x.name, y.data.album ? Number(y.data.album.listeners) : 0, x.url])
        })).then(response => res.send(response))
        break

      case 'tracks':
        Promise.all(response.data.toptracks.track.map(async x => {
          const y = await axios('https://ws.audioscrobbler.com/2.0/?method=track.getinfo&artist=' + encodeURIComponent(x.artist.name) + '&track=' + encodeURIComponent(x.name) + '&api_key=52e8e86c171ed9affffa34580666927a&format=json')
          return Promise.resolve([x.artist.name + ' – ' + x.name, y.data.track ? Number(y.data.track.listeners) : 0, x.url])
        })).then(response => res.send(response))
        break
    }
  }).catch(error => {
    res.send({
      error: error.message
    })
  })
})

app.use(express.static('public'))

app.get('*', (req, res) => {
  res.redirect('/')
})

app.listen(3002, '127.0.0.1')
